﻿function GetVisible(idTipo, key) {
    if (idTipo == 2) {
        if (key == 'menu_investimento') { return true; }
    }

}